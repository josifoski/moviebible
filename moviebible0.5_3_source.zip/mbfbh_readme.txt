Movie Bible 0.5_0 readme

0.5_0 have improvements in search (can search many Bibles).
Reading many Bibles iteratelly.
New lines before Text can be added for vertically centering Text. 
Pause symbol is changed with heart symbol.
Now there is bookmarking. Bookmarked verses are stored in file bookmarks.dat (do not edit that file manually).
New option is stop at position, so when reading in play mode, program will automatically pause at certain verse.
New option in playing mode is also showing chapter at each first verse (from distance ex. bed reading).

Programmer:
Aleksandar Josifoski
josifoski@gmail.com
twitter: josifsk

made in Lazarus 1.0.8

*revelation22,16@heaven.org advices you fell free to arange it (-> Lazarus John 11,25 Rev 22,20 2 Peter 3,10 )
folders Bibles and BooksTitles must be subfolders of current where the code is


Program works on windows vista, 7, 8, Linux, (MacOS need to compile it there)
----------------------

For China and Ethiopia-Amharic   xp users:
upgrade to newer version of windows

Bible texts are in format
-------------------------
$$$1 1:1
In the beginning God created the heavens and the earth.
$$$1 1:2
Now the earth was without shape and empty, and darkness was over the surface of the watery deep, but the Spirit of God was moving over the surface of the water.
$$$1 1:3
God said, �Let there be light.� And there was light!

if Bible translation is missing at your language prepare it in that format (utf8 without bom) & put in Bibles folder. Also appreciate if you send to josifoski@gmail.com to be putted in next release.

Books titles are in utf8 text format
------------------------------------
if your language is missing just create yourlanguage.txt in BooksTitles directory 

Can use Read_Bible_chapters.gnumeric for anotating read heads. If you use install gnumeric, that is program similar to ms_excel or libreoffice_calc much simple.

Shortcuts:
P  Play/Pause 
V   Verse finder
B   Bookmarks
N  Note
M  view verse in many translations
Left   Previous verse
Right   Next verse
Up    reveal verse if % of hiding is choosen
Down   back to hiding if % of hiding is choosen
C  Chapter View in text format
O Show verse position


Licence:  free_gpl. 

In this release 0.5_0 are included 66 Bible texts on many languages/translations
Missing Bible translation? Send it to me and I'll put it in next release James 4,15
Bible texts should be in utf8 without bum
Missing BooksTitles in your language? well, create yourlanguage.txt file and put in BooksTitles 
folder. File must be in utf8.


2013-december
homepage: www.sourceforge.net/projects/mbfbh/ 

can drop eye on
http://sourceforge.net/projects/printcrippledbi/
sourceforge.net/projects/sbrppr/
sourceforge.net/projects/simplebiblegame/


support
For receiving news on updates and discussion
mailing list groups.google.com/group/moviebible


#moviebible at irc.freenode.net 
zimrie_love

To minimize program in systemtray click on trayicon

