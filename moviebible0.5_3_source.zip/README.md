# moviebible
One interesting lazarus based program for exploring Word of Elohim  
  
https://github.com/josifoski/moviebible  
programmer: Aleksandar Josifoski  
https://about.me/josifsk  
  
2021 Octobar  
  
licence: GPL  
  
# Instalation  
You will need Lazarus  
http://www.lazarus-ide.org/  
to (once only) compile  
program for your operating system.  
It's very easy, just open mbfbh.lpr via Lazarus  
File/Open and hit on green triangle icon. (or via Menu Run/Run)  
  
After that you can use only your executable. (mbfbh or mbfbh.exe)  
  
Short video introduction: https://www.youtube.com/watch?v=gQKlFSp0nv4  

If you use this program, I would be happy if you donate  
My Solana/SOL  public address: 9hUruV6DCm7tFgbk8BM7r1NP7xjcUsaAfvP4YwBCzmzA  

Join MovieBible on discord https://discord.gg/H5Ppg7Uu  
